//
//  ViewController.swift
//  Delegate_Protocol
//
//  Created by Tushar on 21/10/17.
//  Copyright © 2017 tushar. All rights reserved.
//

import UIKit

class ViewController: UIViewController , secVCDeelgate
{

    var objseconVC = SecondViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    func getArray(arrayData: NSMutableArray) {
        
        print("secondVC Data :: \(arrayData)")
        
    }
    
    @IBAction func buttonNext(_ sender: UIButton)
    {
        objseconVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        objseconVC.delegate_second =  self
        self.navigationController?.pushViewController(objseconVC, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

