//
//  SecondViewController.swift
//  Delegate_Protocol
//
//  Created by Tushar on 21/10/17.
//  Copyright © 2017 tushar. All rights reserved.
//

import UIKit

protocol secVCDeelgate
{
    func getArray(arrayData : NSMutableArray)
}

class SecondViewController: UIViewController {

    var delegate_second: secVCDeelgate?

    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func buttonPrevious(_ sender: UIButton) {
        
        self.navigationController?.popViewController(animated: true)
    
        let arrayData = NSMutableArray()
        
        arrayData.add("0");
        arrayData.add("1");
        arrayData.add("2");
        arrayData.add("3");
        arrayData.add("4");
        arrayData.add("5");
        arrayData.add("6");
    
        
        delegate_second?.getArray(arrayData: arrayData)
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
